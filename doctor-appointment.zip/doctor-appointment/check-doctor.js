const Database = require("better-sqlite3");

const db = new Database("./database.db", {
  readonly: true
});

console.log("\n========== DOCTORS TABLE ==========");

console.table(
  db.prepare("PRAGMA table_info(doctors)").all()
);

console.log("\n========== APPOINTMENTS TABLE ==========");

console.table(
  db.prepare("PRAGMA table_info(appointments)").all()
);

console.log("\n========== FOREIGN KEYS ==========");

console.table(
  db.prepare("PRAGMA foreign_key_list(appointments)").all()
);

db.close();