const Database = require("better-sqlite3");

const db = new Database("./database.db");

function slugify(value) {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function cleanupDoctors() {
  const doctors = db.prepare(`
    SELECT id, username, name, specialty
    FROM doctors
    ORDER BY specialty, name, id
  `).all();

  const groups = new Map();

  for (const doctor of doctors) {
    const key = `${doctor.specialty}|||${doctor.name}`;

    if (!groups.has(key)) {
      groups.set(key, []);
    }

    groups.get(key).push(doctor);
  }

  const mappings = [];

  for (const group of groups.values()) {
    const sample = group[0];
    const match = sample.name.match(/(\d+)$/);

    if (!match) {
      throw new Error(
        `Cannot identify doctor number: ${sample.name}`
      );
    }

    const number = match[1];
    const expectedUsername =
      `${slugify(sample.specialty)}_${number}`;

    const canonical = group.find(
      doctor => doctor.username === expectedUsername
    );

    if (!canonical) {
      throw new Error(
        `Correct doctor not found for ${sample.name}. ` +
        `Expected username: ${expectedUsername}`
      );
    }

    for (const doctor of group) {
      if (doctor.id !== canonical.id) {
        mappings.push({
          duplicate: doctor,
          keep: canonical
        });
      }
    }
  }

  if (mappings.length === 0) {
    console.log("No duplicate doctors found.");
    return;
  }

  console.log("\n========== CLEANUP PREVIEW ==========");

  for (const item of mappings) {
    const count = db.prepare(`
      SELECT COUNT(*) AS total
      FROM appointments
      WHERE doctor_id = ?
    `).get(item.duplicate.id).total;

    console.log(
      `REMOVE ID ${item.duplicate.id} (${item.duplicate.username})`
    );

    console.log(
      `KEEP ID ${item.keep.id} (${item.keep.username})`
    );

    console.log(`Appointments to transfer: ${count}\n`);
  }

  console.log(`Duplicate doctors found: ${mappings.length}`);

  if (!process.argv.includes("--apply")) {
    console.log("\nPREVIEW ONLY. Nothing was deleted.");
    console.log("After checking this report, run:");
    console.log("node cleanup-doctors.js --apply");
    return;
  }

  const applyCleanup = db.transaction(() => {
    const updateAppointments = db.prepare(`
      UPDATE appointments
      SET doctor_id = ?
      WHERE doctor_id = ?
    `);

    const deleteDoctor = db.prepare(`
      DELETE FROM doctors
      WHERE id = ?
    `);

    for (const item of mappings) {
      updateAppointments.run(
        item.keep.id,
        item.duplicate.id
      );

      deleteDoctor.run(item.duplicate.id);
    }
  });

  applyCleanup();

  const remaining = db.prepare(`
    SELECT COUNT(*) AS total
    FROM doctors
  `).get().total;

  console.log("\n========== CLEANUP COMPLETE ==========");
  console.log(`Remaining doctors: ${remaining}`);
  console.log("Duplicate records removed successfully.");
}

try {
  cleanupDoctors();
} catch (error) {
  console.error("\nCLEANUP STOPPED:", error.message);
} finally {
  db.close();
}