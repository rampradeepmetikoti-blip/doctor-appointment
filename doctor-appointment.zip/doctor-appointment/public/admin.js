"use strict";

// ==========================================
// CAREPOINT ADMIN JAVASCRIPT
// ==========================================

var notice = null;

// ==========================================
// API HELPER
// ==========================================

async function api(url, options) {
    options = options || {};

    var config = {
        method: options.method || "GET",
        credentials: "same-origin",
        headers: {
            "Content-Type": "application/json"
        }
    };

    if (options.body) {
        config.body = JSON.stringify(options.body);
    }

    var response = await fetch(url, config);
    var data = {};

    try {
        data = await response.json();
    } catch (error) {
        data = {};
    }

    if (response.status === 401) {
        window.location.href = "/admin-login.html";
        throw new Error("Please login again.");
    }

    if (!response.ok) {
        throw new Error(data.error || "Request failed.");
    }

    return data;
}

// ==========================================
// DISPLAY MESSAGE
// ==========================================

function showNotice(message, isError) {
    if (!notice) return;

    notice.textContent = message;
    notice.classList.toggle("error", Boolean(isError));
}

// ==========================================
// ESCAPE HTML
// ==========================================

function escapeHtml(value) {
    var element = document.createElement("div");

    element.textContent =
        value === null || value === undefined ? "" : String(value);

    return element.innerHTML;
}

// ==========================================
// ADMIN NAVIGATION
// ==========================================

function initAdminNavigation() {
    var buttons = document.querySelectorAll(
        ".sidebar-link[data-section]"
    );

    var sections = document.querySelectorAll(".dashboard-page");

    buttons.forEach(function (button) {
        button.addEventListener("click", function () {
            var sectionName = button.getAttribute("data-section");

            buttons.forEach(function (item) {
                item.classList.toggle("active", item === button);
            });

            sections.forEach(function (section) {
                section.classList.toggle(
                    "active",
                    section.id === sectionName + "-section"
                );
            });
        });
    });
}

// ==========================================
// LOAD DASHBOARD OVERVIEW
// ==========================================

async function loadOverview() {
    var data = await api("/api/admin/overview");

    var patients = document.getElementById("total-patients");
    var doctors = document.getElementById("total-doctors");
    var appointments = document.getElementById("total-appointments");
    var pending = document.getElementById("pending-appointments");

    // These property names match server.js

    if (patients) {
        patients.textContent = data.patients ?? 0;
    }

    if (doctors) {
        doctors.textContent = data.doctors ?? 0;
    }

    if (appointments) {
        appointments.textContent = data.appointments ?? 0;
    }

    if (pending) {
        pending.textContent = data.pending ?? 0;
    }
}

// ==========================================
// LOAD PATIENTS
// ==========================================

async function loadPatients() {
    var tbody = document.getElementById("patients-body");

    if (!tbody) return;

    var result = await api("/api/admin/patients");

    var patients = Array.isArray(result)
        ? result
        : result.patients || [];

    if (patients.length === 0) {
        tbody.innerHTML =
            "<tr><td colspan='5'>No patients found.</td></tr>";
        return;
    }

    tbody.innerHTML = patients.map(function (patient) {
        return "<tr>" +
            "<td>" + escapeHtml(patient.id) + "</td>" +
            "<td>" + escapeHtml(patient.name) + "</td>" +
            "<td>" + escapeHtml(patient.email) + "</td>" +
            "<td>" + escapeHtml(patient.phone || "-") + "</td>" +
            "<td>" + escapeHtml(patient.created_at || "-") + "</td>" +
            "</tr>";
    }).join("");
}

// ==========================================
// LOAD DOCTORS
// ==========================================

async function loadDoctors() {
    var tbody = document.getElementById("doctors-body");

    if (!tbody) return;

    var result = await api("/api/admin/doctors");

    var doctors = Array.isArray(result)
        ? result
        : result.doctors || [];

    if (doctors.length === 0) {
        tbody.innerHTML =
            "<tr><td colspan='6'>No doctors found.</td></tr>";
        return;
    }

    tbody.innerHTML = doctors.map(function (doctor) {
        return "<tr>" +
            "<td>" + escapeHtml(doctor.id) + "</td>" +
            "<td>" + escapeHtml(doctor.name) + "</td>" +
            "<td>" + escapeHtml(doctor.username) + "</td>" +
            "<td>" + escapeHtml(doctor.specialty) + "</td>" +
            "<td>" + escapeHtml(doctor.working_days || "-") + "</td>" +
            "<td>" + escapeHtml(doctor.start_time || "-") +
            " - " + escapeHtml(doctor.end_time || "-") + "</td>" +
            "</tr>";
    }).join("");
}

// ==========================================
// LOAD APPOINTMENTS
// ==========================================

async function loadAppointments() {
    var tbody = document.getElementById("appointments-body");

    if (!tbody) return;

    var result = await api("/api/admin/appointments");

    var appointments = Array.isArray(result)
        ? result
        : result.appointments || [];

    if (appointments.length === 0) {
        tbody.innerHTML =
            "<tr><td colspan='8'>No appointments found.</td></tr>";
        return;
    }

    tbody.innerHTML = appointments.map(function (appointment) {
        var status = String(appointment.status || "Pending");
        var id = Number(appointment.id);

        return "<tr>" +
            "<td>" + escapeHtml(appointment.patient_name) + "</td>" +
            "<td>" + escapeHtml(appointment.doctor_name) + "</td>" +
            "<td>" + escapeHtml(appointment.specialty) + "</td>" +
            "<td>" + escapeHtml(appointment.date) + "</td>" +
            "<td>" + escapeHtml(appointment.time) + "</td>" +
            "<td>" + escapeHtml(appointment.reason || "-") + "</td>" +

            "<td><span class='status status-" +
            escapeHtml(status.toLowerCase()) + "'>" +
            escapeHtml(status) +
            "</span></td>" +

            "<td>" +
            "<select class='admin-status-select' " +
            "data-appointment-id='" + id + "'>" +

            "<option value='Pending'" +
            (status === "Pending" ? " selected" : "") +
            ">Pending</option>" +

            "<option value='Confirmed'" +
            (status === "Confirmed" ? " selected" : "") +
            ">Confirmed</option>" +

            "<option value='Rejected'" +
            (status === "Rejected" ? " selected" : "") +
            ">Rejected</option>" +

            "<option value='Completed'" +
            (status === "Completed" ? " selected" : "") +
            ">Completed</option>" +

            "</select></td>" +
            "</tr>";
    }).join("");
}

// ==========================================
// LOAD ALL DASHBOARD DATA
// ==========================================

async function loadAll() {
    try {
        await Promise.all([
            loadOverview(),
            loadPatients(),
            loadDoctors(),
            loadAppointments()
        ]);

        showNotice(
            "Dashboard data loaded successfully.",
            false
        );

    } catch (error) {
        showNotice(error.message, true);
    }
}

// ==========================================
// UPDATE APPOINTMENT STATUS
// ==========================================

async function updateAppointment(id, status) {
    try {
        await api("/api/admin/appointments/" + id + "/status", {
            method: "PATCH",
            body: {
                status: status
            }
        });

        showNotice(
            "Appointment status updated successfully.",
            false
        );

        await loadAll();

    } catch (error) {
        showNotice(error.message, true);

        await loadAppointments();
    }
}

// ==========================================
// LOGOUT
// ==========================================

function initAdminLogout() {
    var button = document.getElementById("logout-btn");

    if (!button) return;

    button.addEventListener("click", async function () {
        try {
            var result = await api("/api/logout", {
                method: "POST"
            });

            window.location.href = result.redirect || "/";

        } catch (error) {
            showNotice(error.message, true);
        }
    });
}

// ==========================================
// REFRESH BUTTON
// ==========================================

function initRefresh() {
    var button = document.getElementById("refresh-btn");

    if (!button) return;

    button.addEventListener("click", loadAll);
}

// ==========================================
// APPOINTMENT STATUS CHANGE
// ==========================================

document.addEventListener("change", function (event) {
    var target = event.target;

    if (!target.classList.contains("admin-status-select")) {
        return;
    }

    var id = Number(
        target.getAttribute("data-appointment-id")
    );

    var status = target.value;

    if (id > 0) {
        updateAppointment(id, status);
    }
});

// ==========================================
// START ADMIN DASHBOARD
// ==========================================

document.addEventListener("DOMContentLoaded", async function () {

    notice = document.getElementById("notice");

    if (!document.getElementById("appointments-body")) {
        return;
    }

    initAdminNavigation();
    initAdminLogout();
    initRefresh();

    try {
        var admin = await api("/api/admin/me");

        var adminName = document.getElementById("admin-name");

        if (adminName) {
            adminName.textContent =
                admin.username || "Administrator";
        }

        await loadAll();

    } catch (error) {
        showNotice(error.message, true);
    }
});