"use strict";

// ==================================================
// CAREPOINT - MAIN JAVASCRIPT
// Patient and Doctor Dashboard
// ==================================================

const notice = document.getElementById("notice");

// ==================================================
// API HELPER
// ==================================================

async function api(url, options = {}) {
  const config = {
    credentials: "same-origin",
    ...options,
    headers: {
      ...(options.headers || {})
    }
  };

  if (
    options.body &&
    typeof options.body !== "string"
  ) {
    config.headers["Content-Type"] = "application/json";
    config.body = JSON.stringify(options.body);
  }

  const response = await fetch(url, config);

  let data = {};

  try {
    data = await response.json();
  } catch {
    data = {};
  }

  if (!response.ok) {
    throw new Error(data.error || "Request failed.");
  }

  return data;
}

// ==================================================
// COMMON HELPERS
// ==================================================

function showMessage(element, message, isError = false) {
  if (!element) return;

  element.textContent = message;
  element.classList.toggle("error", isError);
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[char]);
}

function statusClass(status) {
  const value = String(status || "").toLowerCase();

  if (value === "pending") return "status-pending";
  if (value === "confirmed") return "status-confirmed";
  if (value === "completed") return "status-completed";
  if (value === "rejected") return "status-rejected";

  return "";
}

function statusBadge(status) {
  return `
    <span class="status ${statusClass(status)}">
      ${escapeHtml(status || "Unknown")}
    </span>
  `;
}

function setMinDate() {
  const dateInput = document.getElementById("appointment-date");

  if (dateInput) {
    const today = new Date();
    const localDate = new Date(
      today.getTime() - today.getTimezoneOffset() * 60000
    );

    dateInput.min = localDate.toISOString().split("T")[0];
  }
}

// ==================================================
// AUTHENTICATION FORMS
// ==================================================

function handleAuth(formId, endpoint) {
  const form = document.getElementById(formId);

  if (!form) return;

  form.addEventListener("submit", async event => {
    event.preventDefault();

    const button = form.querySelector('button[type="submit"]');
    const originalText = button ? button.textContent : "";

    try {
      if (button) {
        button.disabled = true;
        button.textContent = "Please wait...";
      }

      const values = Object.fromEntries(new FormData(form).entries());

      const result = await api(endpoint, {
        method: "POST",
        body: values
      });

      window.location.href = result.redirect || "/";

    } catch (error) {
      alert(error.message);
    } finally {
      if (button) {
        button.disabled = false;
        button.textContent = originalText;
      }
    }
  });
}

// ==================================================
// PATIENT SIDEBAR NAVIGATION
// ==================================================

function initPatientNavigation() {
  const links = document.querySelectorAll(
    ".sidebar-link[data-page]"
  );

  const pages = document.querySelectorAll(".dashboard-page");

  function showPage(pageName) {
    links.forEach(link => {
      link.classList.toggle(
        "active",
        link.dataset.page === pageName
      );
    });

    pages.forEach(page => {
      page.classList.toggle(
        "active",
        page.id === `${pageName}-page`
      );
    });
  }

  links.forEach(link => {
    link.addEventListener("click", () => {
      showPage(link.dataset.page);
    });
  });

  document.querySelectorAll("[data-go]").forEach(button => {
    button.addEventListener("click", () => {
      showPage(button.dataset.go);
    });
  });
}

// ==================================================
// PATIENT DASHBOARD
// ==================================================

async function initPatientDashboard() {
  const bookingForm = document.getElementById("booking-form");

  if (!bookingForm) return;

  initPatientNavigation();
  setMinDate();

  const specialtySelect = document.getElementById("specialty");
  const doctorSelect = document.getElementById("doctorId");
  const bookingMessage = document.getElementById("booking-message");

  try {
    const [patient, categories] = await Promise.all([
      api("/api/patient/me"),
      api("/api/categories")
    ]);

    const name = patient.name || "Patient";
    const email = patient.email || "";
    const phone = patient.phone || "";

    const welcomeName = document.getElementById("welcome-name");
    const welcomeHeading = document.getElementById("welcome-name-heading");
    const profileName = document.getElementById("patient-profile-name");

    if (welcomeName) welcomeName.textContent = name;
    if (welcomeHeading) welcomeHeading.textContent = name;
    if (profileName) profileName.textContent = name;

    const profileNameDetail = document.getElementById("profile-name");
    const profileEmail = document.getElementById("profile-email");
    const profilePhone = document.getElementById("profile-phone");

    if (profileNameDetail) profileNameDetail.textContent = name;
    if (profileEmail) profileEmail.textContent = email;
    if (profilePhone) profilePhone.textContent = phone;

    document.querySelectorAll(".patient-avatar, .profile-avatar")
      .forEach(element => {
        element.textContent = name.charAt(0).toUpperCase();
      });

    specialtySelect.innerHTML =
      '<option value="">Choose a treatment</option>';

    categories.forEach(category => {
      const option = document.createElement("option");
      option.value = category;
      option.textContent = category;
      specialtySelect.appendChild(option);
    });

    await loadPatientAppointments();

  } catch (error) {
    alert(error.message);
    return;
  }

  // Load doctors when treatment changes.
  specialtySelect.addEventListener("change", async () => {
    doctorSelect.innerHTML =
      '<option value="">Loading doctors...</option>';

    if (!specialtySelect.value) {
      doctorSelect.innerHTML =
        '<option value="">Choose a treatment first</option>';
      return;
    }

    try {
      const doctors = await api(
        `/api/doctors?specialty=${encodeURIComponent(specialtySelect.value)}`
      );

      doctorSelect.innerHTML =
        '<option value="">Choose a doctor</option>';

      doctors.forEach(doctor => {
        const option = document.createElement("option");
        option.value = doctor.id;
        option.textContent = doctor.name;
        doctorSelect.appendChild(option);
      });

      if (doctors.length === 0) {
        doctorSelect.innerHTML =
          '<option value="">No doctors available</option>';
      }

    } catch (error) {
      doctorSelect.innerHTML =
        '<option value="">Unable to load doctors</option>';

      showMessage(bookingMessage, error.message, true);
    }
  });

  // Book appointment.
  bookingForm.addEventListener("submit", async event => {
    event.preventDefault();

    try {
      const values = Object.fromEntries(
        new FormData(bookingForm).entries()
      );

      await api("/api/appointments", {
        method: "POST",
        body: {
          doctorId: Number(values.doctorId),
          date: values.date,
          time: values.time,
          reason: values.reason
        }
      });

      showMessage(
        bookingMessage,
        "Appointment booked successfully!"
      );

      bookingForm.reset();
      doctorSelect.innerHTML =
        '<option value="">Choose a treatment first</option>';

      setMinDate();

      await loadPatientAppointments();

    } catch (error) {
      showMessage(bookingMessage, error.message, true);
    }
  });

  const refreshButton = document.getElementById("refresh-patient");

  if (refreshButton) {
    refreshButton.addEventListener("click", loadPatientAppointments);
  }
}

// ==================================================
// LOAD PATIENT APPOINTMENTS
// ==================================================

async function loadPatientAppointments() {
  const tbody = document.getElementById("patient-appointments");

  if (!tbody) return;

  try {
    const appointments = await api("/api/patient/appointments");

    if (!appointments.length) {
      tbody.innerHTML = `
        <tr>
          <td colspan="6">No appointments booked yet.</td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = appointments.map(appointment => `
      <tr>
        <td>${escapeHtml(appointment.doctor_name)}</td>
        <td>${escapeHtml(appointment.specialty)}</td>
        <td>${escapeHtml(appointment.date)}</td>
        <td>${escapeHtml(appointment.time)}</td>
        <td>${escapeHtml(appointment.reason || "-")}</td>
        <td>${statusBadge(appointment.status)}</td>
      </tr>
    `).join("");

  } catch (error) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6">${escapeHtml(error.message)}</td>
      </tr>
    `;
  }
}

// ==================================================
// DOCTOR SIDEBAR NAVIGATION
// ==================================================

function initDoctorNavigation() {
  const links = document.querySelectorAll(
    ".sidebar-link[data-doctor-page]"
  );

  const pages = document.querySelectorAll(".dashboard-page");

  function showPage(pageName) {
    links.forEach(link => {
      link.classList.toggle(
        "active",
        link.dataset.doctorPage === pageName
      );
    });

    pages.forEach(page => {
      page.classList.toggle(
        "active",
        page.id === `doctor-${pageName}-page`
      );
    });
  }

  links.forEach(link => {
    link.addEventListener("click", () => {
      showPage(link.dataset.doctorPage);
    });
  });

  document.querySelectorAll("[data-doctor-go]").forEach(button => {
    button.addEventListener("click", () => {
      showPage(button.dataset.doctorGo);
    });
  });
}

// ==================================================
// DOCTOR DASHBOARD
// ==================================================

async function initDoctorDashboard() {
  const appointmentsTable = document.getElementById("doctor-appointments");

  if (!appointmentsTable) return;

  initDoctorNavigation();

  try {
    const doctor = await api("/api/doctor/me");

    const name = doctor.name || "Doctor";
    const specialty = doctor.specialty || "";

    const doctorName = document.getElementById("doctor-name");
    const doctorWelcome = document.getElementById("doctor-welcome-name");
    const doctorSpecialty = document.getElementById("doctor-specialty");

    const profileName = document.getElementById("doctor-profile-name");
    const profileSpecialty = document.getElementById("doctor-profile-specialty");

    const profileNameDetail =
      document.getElementById("doctor-profile-name-detail");

    const profileSpecialtyDetail =
      document.getElementById("doctor-profile-specialty-detail");

    if (doctorName) doctorName.textContent = name;
    if (doctorWelcome) doctorWelcome.textContent = name;
    if (doctorSpecialty) doctorSpecialty.textContent = specialty;

    if (profileName) profileName.textContent = name;
    if (profileSpecialty) profileSpecialty.textContent = specialty;

    if (profileNameDetail) profileNameDetail.textContent = name;
    if (profileSpecialtyDetail) {
      profileSpecialtyDetail.textContent = specialty;
    }

    document.querySelectorAll(".doctor-avatar").forEach(element => {
      element.textContent = name.charAt(0).toUpperCase();
    });

    // Load current schedule.
    const scheduleForm = document.getElementById("schedule-form");

    if (scheduleForm) {
      const days = String(doctor.working_days || "")
        .split(",")
        .map(day => day.trim());

      scheduleForm.querySelectorAll(
        'input[name="workingDays"]'
      ).forEach(checkbox => {
        checkbox.checked = days.includes(checkbox.value);
      });

      scheduleForm.elements.startTime.value =
        doctor.start_time || "09:00";

      scheduleForm.elements.endTime.value =
        doctor.end_time || "17:00";

      scheduleForm.addEventListener("submit", async event => {
        event.preventDefault();

        const message = document.getElementById("schedule-message");

        try {
          const workingDays = Array.from(
            scheduleForm.querySelectorAll(
              'input[name="workingDays"]:checked'
            )
          ).map(input => input.value);

          if (workingDays.length === 0) {
            throw new Error("Select at least one working day.");
          }

          const startTime = scheduleForm.elements.startTime.value;
          const endTime = scheduleForm.elements.endTime.value;

          if (startTime >= endTime) {
            throw new Error("Ending time must be after starting time.");
          }

          await api("/api/doctor/schedule", {
            method: "PUT",
            body: {
              workingDays,
              startTime,
              endTime
            }
          });

          showMessage(message, "Schedule updated successfully!");

        } catch (error) {
          showMessage(message, error.message, true);
        }
      });
    }

    await loadDoctorAppointments();

  } catch (error) {
    alert(error.message);
  }

  const refreshButton = document.getElementById("refresh-doctor");

  if (refreshButton) {
    refreshButton.addEventListener("click", loadDoctorAppointments);
  }
}

// ==================================================
// LOAD DOCTOR APPOINTMENTS
// ==================================================

async function loadDoctorAppointments() {
  const tbody = document.getElementById("doctor-appointments");

  if (!tbody) return;

  try {
    const appointments = await api("/api/doctor/appointments");

    if (!appointments.length) {
      tbody.innerHTML = `
        <tr>
          <td colspan="8">No appointments found.</td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = appointments.map(appointment => {
      const status = String(appointment.status || "").toLowerCase();

      let actions = "-";

      if (status === "pending") {
        actions = `
          <button class="dashboard-primary-btn"
            data-appointment-action="Confirmed"
            data-id="${Number(appointment.id)}">
            Confirm
          </button>

          <button class="dashboard-secondary-btn"
            data-appointment-action="Rejected"
            data-id="${Number(appointment.id)}">
            Reject
          </button>
        `;
      } else if (status === "confirmed") {
        actions = `
          <button class="dashboard-primary-btn"
            data-appointment-action="Completed"
            data-id="${Number(appointment.id)}">
            Complete
          </button>
        `;
      }

      return `
        <tr>
          <td>${escapeHtml(appointment.patient_name)}</td>
          <td>${escapeHtml(appointment.patient_email)}</td>
          <td>${escapeHtml(appointment.patient_phone)}</td>
          <td>${escapeHtml(appointment.date)}</td>
          <td>${escapeHtml(appointment.time)}</td>
          <td>${escapeHtml(appointment.reason || "-")}</td>
          <td>${statusBadge(appointment.status)}</td>
          <td>${actions}</td>
        </tr>
      `;
    }).join("");

  } catch (error) {
    tbody.innerHTML = `
      <tr>
        <td colspan="8">${escapeHtml(error.message)}</td>
      </tr>
    `;
  }
}

// ==================================================
// DOCTOR APPOINTMENT STATUS ACTIONS
// ==================================================

document.addEventListener("click", async event => {
  const button = event.target.closest("[data-appointment-action]");

  if (!button) return;

  const id = Number(button.dataset.id);
  const status = button.dataset.appointmentAction;

  if (!id || !status) return;

  try {
    button.disabled = true;

    await api(`/api/appointments/${id}/status`, {
      method: "PATCH",
      body: { status }
    });

    await loadDoctorAppointments();

  } catch (error) {
    alert(error.message);
    button.disabled = false;
  }
});

// ==================================================
// LOGOUT
// ==================================================

function initLogout() {
  document.querySelectorAll("[data-logout]").forEach(button => {
    button.addEventListener("click", async () => {
      try {
        const result = await api("/api/logout", {
          method: "POST"
        });

        window.location.href = result.redirect || "/";
      } catch (error) {
        alert(error.message);
      }
    });
  });
}

// ==================================================
// START APPLICATION
// ==================================================

document.addEventListener("DOMContentLoaded", () => {

  handleAuth(
    "register-form",
    "/api/patient/register"
  );

  handleAuth(
    "patient-login-form",
    "/api/patient/login"
  );

  handleAuth(
    "doctor-login-form",
    "/api/doctor/login"
  );

  handleAuth(
    "admin-login-form",
    "/api/admin/login"
  );

  initPatientDashboard();
  initDoctorDashboard();
  initLogout();

});